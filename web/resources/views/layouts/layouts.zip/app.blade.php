<!DOCTYPE html> 
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>Valeny | Joyas Colombia Oro Plata Acero - Joyas de Oro y Plata - Por mayor y Catálogo - Fabricantes. JOYAS DE PLATA Y ORO. Venta de joyas de oro y plata por mayor. Joyas de acero, en acero al por mayor, acero quirúrgico, anillos, pulseras, dijes, aretes, sets.</title>
  

  <meta name="description" content="Joyería Colombiana, joyas de oro y plata, joyería oro plata,  Bucaramanga - Colombia.  Joyas de oro y plata en latinoamerica, Miami, USA, Panamá, Chile. Somos fabricantes con los  mejores precios. Envíos internacionales. Anillos, brazaletes, pulseras, aretes, sortijas, anillos de matrimonio. Joyas de plata y oro por mayor. Fabricantes y mayoristas joyas de oro y plata. Joyerías en Colombia, Panamá, Chile y Miami. Acero quirúrgico Colombia, Joyas de Acero por mayor, joyas en oro plata, platería online, joyas de Colombia al por mayor, Catálogo de joyas en oro plata. Acero por mayor joyas, plata ley 925, mejor marca de joyas en colombia, Fábrica de joyas, joyas por mayor.Anillos de oro y plata, Dijes de oro rosado, Anillos de Acero, Pulseras de Acero, Juegos de joyas, Sets de joyas.joyas de acero al por mayor, joyas por mayor." />
<meta name="keywords" content= "joyeria colombiana, oro plata,joyas en oro y plata,joyas de oro y plata,joyeria colombiana,anillos en oro,anillos en plata,anillos,anillos de matrimonio, anillos de oro,anillos de plata, anillos de oro plata,joyas colombianas,pulseras,brazaletes,joyas de oro,joyas de plata,joyeros en chile,joyeros en miami,joyeros en panamá,joyeros en colombia,joyeros en Estados unidos,anillos de compromiso,Panamá,Chile,Miami,USA,Colombia.Fabricantes y mayoristas joyas de oro y plata, taller de joyería, fabrica de joyas oro 14 kilates, oro 18 kilates, oro 10 kilates Joyerías en Colombia, Panamá, Chile y Miami,  Colombia, Joyas de oro  por mayor,joyas prototipado, casting, joyas en oro plata, platería online, joyas de Colombia al por mayor, Catálogo de joyas en oro plata. Catálogo  por mayor joyas, plata ley 925, mejor marca de joyas en Colombia, empresa oficial de oro plata colombia, Fábrica de joyas, joyas por mayor.Anillos de oro y plata, Dijes de oro rosado, Anillos de Acero, Pulseras de plata oro , Juegos de joyas, Sets de joyas.Set De Joyas, Set De Joyas Swarovski Elements, Set De Joyas , anillos, aretes, dijes, pendientes, prendas, alhajas, topos, hoguis, anillos onix, anillos ágata, joyas esmeralda, argollas, anillos solitarios Set De Joyas Al Por Mayor, Set De Joyas y joyas , Set De Joyas De plata , Joyas Al Por Mayor, Joyas Al Por Mayor Miami, Joyas Al Por Mayor Santiago, Joyas Al Por Mayor Argentina, Joyas Al Por Mayor En Concepcion, Joyas Al Por Mayor Bogota, Joyas Al Por Mayor En Lima, Joyas Al Por Mayor En Santiago Centro, Joyas Al Por Mayor De Acero Quirurgico, Joyas Al Por Mayor Colombia, Conjunto Joyas, Conjunto Joyas Novia, Conjunto Joyas Plata, Conjunto Joyas Para Novias, Conjunto Joyas de compromiso ,anillos solitarios, debodas, Conjunto Joyas De Vallejo, Conjunto Las Joyas De oro, taller  De Joyas, Taxco Joyas Del Marques, joyerias Medellín De Joyas De Alto Valor, Juego De Joyas, Juego De Joyas Y Diamantes, Juego De Joyas en amatista , Joyas Y Diamantes , Juego De Joyas Bejeweled, Juego De Joyas Y Gemas, Juego De Joyas Y Gemas Alejandra, joyas Cotrino , Juego De Joyas Antiguas , Juego De Joyas En Linea, Juego De Joyas Online, Joyas Online, Joyas Online Espana, Joyas Online Baratas, Joyas Online Argentina, Joyas Online Outlet, Joyas Online Colombia, Joyas Online Peru, Joyas Online Plata, Joyas Online Mexico, Joyas Online plata 925, solo plata Exclusividad Y Elegancia, Joyas De Colombia, Joyas Colombianas De Oro, Joyas Precolombinas De Colombia, Joyas Artesanales De Colombia, Joyas Colombianas Hechas A Mano, Joyas Colombianas Esmeraldas, Disenadores De Joyas Colombianas, Joyas Colombianas De Exportacion, Joyas Colombianas De plata oro , Joyeria De Colombia, Joyas De Oro Y Plata, Joyas De Oro Y Plata Por Mayor, Joyas De Oro Y Plata Por Catalogo, Joyas De Oro Y Plata Para Revender, Joyas De Oro Y Plata Precios, Joyas De Oro Y Plata Para Vender, Joyas De Oro Y Plata Al Por Mayor, joyas por catalogo, Joyas De Oro Y Plata Para Vender Por Catalogo, Joyas De Oro Y Plata Venta Por Mayor, Joyas De Oro Y Plata Por Mayor En Tucuman,joyas az  Joyerias En Miami, Joyerias, Joyerias plata , Joyerias 925 plata , Joyerias En Monterrey, Joyerias En Guadalajara, Joyerias Bogota, Joyerias Cristal, Joyerias En Tijuana, Joyerias En Colombia, Joyas Por Mayor, Joyas Por Mayoreo, Joyas Por Mayor Chile, Joyas Por Mayor Santiago, Joyas Por Mayor , Joyas Por Mayor Plata, Joyas Por Mayor Acero Quirurgico, Joyas Por Mayor Plata Y Oro, Joyas Por Mayor Argentina, Joyas Por Mayor guatemala, Joyas De Oro, Joyas De Oro Peru, Joyas De Oro Y Plata, Joyas De Oro Por Catalogo, Joyas De Oro Mexicano, Joyas De Oro Blanco, Joyas De Oro 18 Kilates, Joyas De Oro Ecuatoriano, Joyas De Plata, Joyas De Plata 925, Joyas De Plata Por Mayor, Joyas De Plata Mexicana, Joyas De Plata Chile, Joyas De Plata Peruana Por Catalogo, Joyas De Plata Peru, Joyas De Plata Peruana, Joyas De Plata 925, Joyas De Plata Online, Anillos De Oro Y Plata, Anillos De Oro Y Plata Con Piedras, Anillos De Oro Y Plata Hombre, Anillos De Oro Y Plata Precio, Anillos De Oro Y Plata Con Iniciales, Anillos De Oro Y Plata Para Mujeres, Anillos De Oro Y Plata Para Hombres, Anillos De Oro Y Plata Matrimonio, joyas onix  Anillos De Oro Y Plata Catalogo, Anillos De Oro Y Plata Por Mayor, Colgantes De Oro Y Plata, Colgantes Oro Y Plata, cadenas plata, anillos plata, aretes plata, aretes plata oro, dijes en plata y oro, Oro Y Plata, Oro Y Plata Mariachi Chicago, Oro Y Plata Bonaire , Oro Y Plata francia, Oro Y Plata curacao, joyas oro plata miami, joyas plata oro Aruba, joyas oro plata las vegas, joyas hechas a mano, joyerias en plata oro los ángeles, joyas en oro y plata Montevideo, joyas plata oro Asunción, joyas plata oro Quito, joyas Guayaquil, joyas Honduras, joyas el Salvador, joyas Santiago, joyas Uruguay, joyas miami, joyas virginia, joyas atlanta, joyas georgia, joyas Taxco, Oro Y Plata , Oro Y Plata , Oro Y Plata  Gallery, Oro Y Plata, Oro Y Plata Internacional, Pulseras Oro Plata, Pulseras Oro Plata Y Bronce, Pulseras Oro Y Plata, Pulseras Oro Y Plata Precios, Pulseras De Oro Plata, Pulsera De Oro Plata, Pulsera Oro Y Plata Hombre, Pulseras De Oro Y Plata Para Mujer, Pulseras De Oro Y Plata Para Hombres, rings 925, earrings 925, silver 925, silver 950, silver gold, gold, Pulseras Plata Oro, bracelets, pendants, rings silver, earrings silver 925, joyas oro plata Nicaragua, joyas Tegucigalpa, joyas Yoro Yoro, joyas San diego, joyas plata silver, joyería en plata, joyería en solo plata, plata y oro, limpieza de joyas, como limpiar las joyas. Jade joyas, joyas coralina joyas lapislázuli, joyas piedras naturales oro plata, apretás oro plata, candongas oro plata, aros oro plata, aros rígidos oro plata, aros melicocha , aretes omega, anillos cuarzo oro plata, joyas costa rica, joyas Colón, joyas Bolivia, joyas la paz, joyerias, sao Paulo, joyas en zafiro azul, joyas en ruby, joyas en agua marina, joyas en topacio, joyas en la Florida, joyas en orlando, joyas para Negocio, precios por mayor, precios de distribuidor, joyas oro plata virginia, joyas wasintong, joyas D. C., joyas Popayán, joyas Ipiales, joyas Armenia, joyas Pereira, joyas Cartagena, joyas sincelejo, joyas montería, joyas Barranquilla, joyas Valledupar, joyas Manizales, joyas Pereira, joyas cartago, joyas Heredia, joyas Guadalajara, joyas puerta de oro, show de Joyeros, show de joyas oro plata, joyas rodinadas, joyas en rodio. Joyas oro blanco , oro plata joyas, oro plata rodinado, joyas con brillo, joyas willy, joyas jhons, accesorios para joyería, joyas y mas, joyas en oro, joyas en oro plata exclusivas, joyas globalizacion, globalizado las joyas, joyas silver, joyas silva, taller de plata, taller de oro, joyas bucaramanga, oro plata bucaramanga, joyerias bucaramanga, joyas colombianas de plata, ferias de joyas, ferias de joyería, ferias de joyería oro plata, show de joyas oro plata, show oro plata, show plata oro , joyas bisel, joyas para regalar, joyas San Valentín, joyas para amor y amistad, oro plata san Valentín, san Valentín joyas, joyas la isla, joyas oro plata frank, joyas Suecia, joyas holanda, joyas arizona, joyas oro plata a rizoma, joyas oro plata San Francisco, joyas jupiter, joyas kissime, oro plata kissime. Joyas Canadá, oro plata Canadá, oro plata Toronto, plata oro nueva Jersey, New jersey joyas oro plata, joyas oro plata paris, joyas oro plata Marsella, joyas oro plata aix provence. Joyas oro plata montería, joyas oro plata la guajira, joyas oro plata los cayos." />

   <link rel="stylesheet" type="text/css" href="{{ asset('css/bootstrap.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/font-awesome.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/animate.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/owl.carousel.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/owl.transitions.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/cubeportfolio.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/jquery.fancybox.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/bootsnav.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/settings.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/loader.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/style.css') }}">
    <link rel="shortcut icon" href="{{ asset('images/favicon.png') }}">


</head>
<body>

    <!--Loader-->
    <div class="loader">
      <div class="spinner-load">
        <div class="dot1">
        </div>
        <div class="dot2">
        </div>
      </div>
    </div>

<style type="text/css">
  .flotante {
    display:scroll;
        position:fixed;
        bottom:20px;
        right:10px;
        z-index: 7;
        
}

</style>

    <a class='flotante' href='https://wa.me/573103766113' ><img src='wp.png' border="0"/></a>
<div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/es_ES/sdk.js#xfbml=1&version=v6.0&appId=911147282569450&autoLogAppEvents=1"></script>
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5e41ca9ca89cda5a188534cc/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->

    <!--TOPBAR-->
    <div class="topbar">
      <div class="container">
        <div class="row">
          <div class="col-sm-4">
            <div class="header-top-entry">
              <div class="title">
                IDIOMA
                <i class="fa fa-angle-down">
                </i>
              </div>
              <div class="list">
               <!-- GTranslate: https://gtranslate.io/ -->
<a href="#" onclick="doGTranslate('es|en');return false;" title="English" class="gflag nturl" style="background-position:-0px -0px;"><img src="//gtranslate.net/flags/blank.png" height="24" width="24" alt="English" /></a><a href="#" onclick="doGTranslate('es|fr');return false;" title="French" class="gflag nturl" style="background-position:-200px -100px;"><img src="//gtranslate.net/flags/blank.png" height="24" width="24" alt="French" /></a><a href="#" onclick="doGTranslate('es|de');return false;" title="German" class="gflag nturl" style="background-position:-300px -100px;"><img src="//gtranslate.net/flags/blank.png" height="24" width="24" alt="German" /></a><a href="#" onclick="doGTranslate('es|it');return false;" title="Italian" class="gflag nturl" style="background-position:-600px -100px;"><img src="//gtranslate.net/flags/blank.png" height="24" width="24" alt="Italian" /></a><a href="#" onclick="doGTranslate('es|pt');return false;" title="Portuguese" class="gflag nturl" style="background-position:-300px -200px;"><img src="//gtranslate.net/flags/blank.png" height="24" width="24" alt="Portuguese" /></a><a href="#" onclick="doGTranslate('es|ru');return false;" title="Russian" class="gflag nturl" style="background-position:-500px -200px;"><img src="//gtranslate.net/flags/blank.png" height="24" width="24" alt="Russian" /></a><a href="#" onclick="doGTranslate('es|es');return false;" title="Spanish" class="gflag nturl" style="background-position:-600px -200px;"><img src="//gtranslate.net/flags/blank.png" height="24" width="24" alt="Spanish" /></a>

<style type="text/css">
<!--
a.gflag {vertical-align:middle;font-size:24px;padding:1px 0;background-repeat:no-repeat;background-image:url(//gtranslate.net/flags/24.png);}
a.gflag img {border:0;}
a.gflag:hover {background-image:url(//gtranslate.net/flags/24a.png);}
#goog-gt-tt {display:none !important;}
.goog-te-banner-frame {display:none !important;}
.goog-te-menu-value:hover {text-decoration:none !important;}
body {top:0 !important;}
#google_translate_element2 {display:none!important;}
-->
</style>

<br /><select onchange="doGTranslate(this);"><option value="">Select Language</option><option value="es|ar">Arabic</option><option value="es|zh-CN">Chinese (Simplified)</option><option value="es|en">English</option><option value="es|fr">French</option><option value="es|de">German</option><option value="es|it">Italian</option><option value="es|ja">Japanese</option><option value="es|ko">Korean</option><option value="es|pt">Portuguese</option><option value="es|ru">Russian</option><option value="es|es">Spanish</option></select><div id="google_translate_element2"></div>
<script type="text/javascript">
function googleTranslateElementInit2() {new google.translate.TranslateElement({pageLanguage: 'es',autoDisplay: false}, 'google_translate_element2');}
</script><script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit2"></script>


<script type="text/javascript">
/* <![CDATA[ */
eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('6 7(a,b){n{4(2.9){3 c=2.9("o");c.p(b,f,f);a.q(c)}g{3 c=2.r();a.s(\'t\'+b,c)}}u(e){}}6 h(a){4(a.8)a=a.8;4(a==\'\')v;3 b=a.w(\'|\')[1];3 c;3 d=2.x(\'y\');z(3 i=0;i<d.5;i++)4(d[i].A==\'B-C-D\')c=d[i];4(2.j(\'k\')==E||2.j(\'k\').l.5==0||c.5==0||c.l.5==0){F(6(){h(a)},G)}g{c.8=b;7(c,\'m\');7(c,\'m\')}}',43,43,'||document|var|if|length|function|GTranslateFireEvent|value|createEvent||||||true|else|doGTranslate||getElementById|google_translate_element2|innerHTML|change|try|HTMLEvents|initEvent|dispatchEvent|createEventObject|fireEvent|on|catch|return|split|getElementsByTagName|select|for|className|goog|te|combo|null|setTimeout|500'.split('|'),0,{}))
/* ]]> */
</script>

                
              </div>
            </div>
            
          </div>
           @if(Auth::user() )
         <div class="col-sm-8 header-top-entry ">
              <div class="title">
                 <i class="fa fa-user">
                  </i> CUENTA
                <i class="fa fa-angle-down">
                </i>
              </div>
              <div class="list"> 
                <b>{{Auth::user()->name}}</b>
                <a class="list-entry" href="#.">INFORMACIÓN GENERAL
                </a>
                <a class="list-entry" href="{{ route('logout') }}"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                    <div class="notification">
                                        <div class="notification-content"><i class="fa fa-power-off"></i>SALIR</div>
                                    </div>
                                </a>
                                <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                        @csrf
                                    </form>
              </div>
            </div>
          @else
           <div class="col-sm-8">
                      <ul class="top_link">
                        <li>
                          <a href="{{route('login')}}" class="uppercase">Entrar
                          </a>
                        </li>
                      </ul>
                    </div>
          @endif
        </div>
      </div>
    </div>
    <!--HEADER-->
   <header>
      <nav class="navbar navbar-default navbar-sticky bootsnav">
        <div class="container">
          <div class="attr-nav">
            <ul>
              <li class="cart-toggler">
                 @if(Auth::user() && Auth::user()->tipo =='superadmin')
                
                @else
                
                @endif
              </li>
              <li class="search">
                <a href="#.">
                  <i class="fa fa-search">
                  </i>
                </a>
              </li>
            </ul>
          </div>
          <!-- Start Header Navigation -->
          <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
              <i class="fa fa-bars">
              </i>
            </button>
            <a class="navbar-brand" href="{{route('home')}}">
              <img src="{{ asset('images/logo.png') }}" class="logo" alt="">
            </a>
          </div>
          <!-- End Header Navigation -->
          <div class="collapse navbar-collapse" id="navbar-menu">
            @if(Auth::user() && Auth::user()->tipo =='superadmin')
            <ul class="nav navbar-nav navbar-right" data-in="fadeIn" data-out="fadeOut">
              <li>
                <a href="{{route('home')}}">Inicio
              </a>
              </li>
              <li>
                <a href="{{route('joyas')}}">Productos
                </a>
              </li>
              <li>
                <a href="{{route('solicitar.catalogo')}}">Catálogos
                </a>
              </li>
              <li>
                <a href="{{route('boletin')}}">Boletin
                </a>
              </li>
            </ul>
            @else
            <ul class="nav navbar-nav navbar-right" data-in="fadeIn" data-out="fadeOut">
              <li>
                <a href="{{route('home')}}">Inicio
                </a>
              </li>
              <li class="dropdown megamenu-fw">
                <a href="{{route('joyas.oroplata')}}" class="dropdown-toggle" >Productos
                </a>
                <ul class="dropdown-menu megamenu-content" role="menu">
                  <li>
                    <div class="row">
                      <div class="col-menu col-md-3">
                        <a href="{{route('joyas.oroplata')}}"><h5 class="title heading_border">Oro y plata</a>
                        </h5>
                        <div class="content">
                          <ul class="menu-col">
                            <li>
                              <a href="{{route('anillos.colombia')}}">Anillos
                              </a>
                            </li>
                            <li>
                              <a href="{{route('pulseras.colombia')}}">Pulseras y Aros
                              </a>
                            </li>
                            <li>
                              <a href="{{route('sets.colombia')}}">Sets
                              </a>
                            </li> 
                          </ul>
                        </div>
                      </div>
                      <div class="col-menu col-md-3">
                        <h5 class="title heading_border">Oro y plata
                        </h5>
                        <div class="content">
                          <ul class="menu-col">
                            <li>
                              <a href="{{route('dijes.colombia')}}">Dijes
                              </a>
                            </li>
                            <li>
                              <a href="{{route('collares.colombia')}}">Collares
                              </a>
                            </li>
                            <li>
                              <a href="{{route('boda.colombia')}}">Boda
                              </a>
                            </li>
                          </ul>
                        </div>
                      </div>  
                      <div class="col-menu col-md-3">
                        <div class="content">
                          <img src="{{ asset('images/mega-menu.png') }}"  alt="menu" class="img-responsive">
                        </div>
                      </div>
                    </div>
                  </li>
                </ul>
              </li>
              <li>
                <a href="{{route('home')}}/#sobre">Nosotros
                </a>
              </li>
              <li>
                <a href="{{route('catalogo')}}">Solicitar Catálogo
                </a>
              </li>
              <li>
                <a href="{{route('contacto')}}">Contáctanos
                </a>
              </li>

            </ul>
            @endif
          </div>
          <!-- /.navbar-collapse -->
          <div class=" search-toggle">
            <div class="top-search">
              <div class="input-group">
                <input type="text" class="form-control" placeholder="Search">
                <span class="input-group-addon">
                  <i class="fa fa-search">
                  </i>
                </span>
              </div>
            </div>
          </div>
          <!--<ul class="cart-list">
            <li>
              <a href="#." class="photo">
                <img src="images/hover-cart.jpg" class="cart-thumb" alt="" />
              </a>
              <h6>
                <a href="#.">Descripción producto 
                </a>
              </h6>
              <p>Qty: 2 
                <span class="price">$170.00
                </span>
              </p>
            </li>
            <li class="total clearfix">
              <div class="pull-right">
                <strong>Shipping
                </strong>: $5.00
              </div>
              <div class="pull-left">
                <strong>Total
                </strong>: $173.00
              </div>
            </li>
            <li class="cart-btn">
              <a href="#." class="active">VER CARRITO
              </a>
              <a href="#.">COTIZAR
              </a>
            </li>
          </ul>
          <ul class="cart-list">
            <li>
              <a href="#." class="photo">
                <img src="images/hover-cart.jpg" class="cart-thumb" alt="" />
              </a>
              <h6>
                <a href="#.">user
                </a>
              </h6>
              <p>Qty: 2 
                <span class="price">$170.00
                </span>
              </p>
            </li>
            <li class="total clearfix">
              <div class="pull-right">
                <strong>Shipping
                </strong>: $5.00
              </div>
              <div class="pull-left">
                <strong>Total
                </strong>: $173.00
              </div>
            </li>
            <li class="cart-btn">
              <a href="#." class="active">VER CARRITO
              </a>
              <a href="#.">COTIZAR
              </a>
            </li>
          </ul>-->
        </div>   
      </nav>
    </header>



    @yield('content')


<!--Footer-->
    <footer class="padding_top bottom_half">
      <a href="#." class="go-top text-center">
        <i class="fa fa-angle-double-up">
        </i>
      </a>
      <div class="container">
        <div class="row">
          <div class="col-md-3 col-sm-6">
            <div class="footer_panel content_space">
              <h4 class="heading_border heading_space">Sobre la tienda
              </h4>
              <ul class="about_foot">
                <li>
                  <i class="fa fa-home">
                  </i>Colombia, Argentina, Chile, Miami, Ecuador ,Panamá,Costa Rica, Mexico, Estados Unidos.
                </li>
                <li>
                  <i class="fa fa-phone">
                  </i>(+57) 3016469607
                </li>
                <li>
                  <a href="#.">
                    <i class="fa fa-envelope-o">
                    </i>info@valeny.com
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div class="col-md-3 col-sm-6">
            <div class="footer_panel content_space">
              <h4 class="heading_border heading_space">My Account
              </h4>
              <ul class="account_foot">
                <li>
                  <a href="#.">MI CUENTA
                  </a>
                </li>
                <li>
                  <a href="#.">Ingreso
                  </a>
                </li>
                <li>
                  <a href="#.">Registrarme
                  </a>
                </li>
               
                
              </ul>
            </div>
          </div>
          <div class="col-md-3 col-sm-6">
            <div class="footer_panel content_space">
              <h4 class="heading_border heading_space">INFORMACIÓN 
              </h4>
              <ul class="account_foot">
                <li>
                  <a href="{{route('devoluciones')}}">Devoluciones
                  </a>
                </li>
                <li>
                  <a href="{{route('politicas')}}">Politicas de privacidad
                  </a>
                </li>
                <li>
                  <a href="{{route('home')}}/#sobre">Sobre nosotros
                  </a>
                </li>
                <li>
                  <a href="{{route('garantia')}}">Garantía
                  </a>
                </li>
                <li>
                  <a href="{{route('como.comprar')}}">¿Cómo comprar?
                  </a>
                </li>
                <li>
                  <a href="#.">Preguntas frecuentes
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div class="col-md-3 col-sm-6">
            <div class="footer_panel content_space">
              <h4 class="heading_border heading_space">ALIADOS
              </h4>
              <ul class="account_foot">
                <li>
                  <a href="https://www.camaradirecta.com/"><img src="{{ asset('images/camara.png')}}" width="60%">
                  </a>
                </li>
                <li>
                  <a href="https://procolombia.co/"><img src="{{ asset('images/pro.png')}}" width="60%">
                  </a>
                </li>
                
              </ul>
            </div>
          </div>
        </div>
      </div>
    </footer>
    <div class="copyright">
      <div class="container">
        <div class="row">
          <div class="col-sm-4">
            <p>Copyright &copy; 2020 
              <a href="#.">Valeny Joyas
              </a>. Todos los derechos reservados.
            </p>
          </div>
          <div class="col-sm-8">
            <ul class="social">
              <li>
                <a href="#.">
                  <i class="fa fa-facebook">
                  </i>
                </a>
              </li>
              <li>
                <a href="#.">
                  <i class="fa fa-twitter">
                  </i>
                </a>
              </li>
              <li>
                <a href="#.">
                  <i class="fa fa-rss">
                  </i>
                </a>
              </li>
              <li>
                <a href="#.">
                  <i class="fa fa-google-plus">
                  </i>
                </a>
              </li>
              <li>
                <a href="#.">
                  <i class="fa fa-linkedin">
                  </i>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>


  <script src="{{ asset('js/jquery-2.2.3.js') }}">
    </script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAOBKD6V47-g_3opmidcmFapb3kSNAR70U">
    </script>
    <script src="{{ asset('js/gmap3.min.js') }}">
    </script>
    <script src="{{ asset('js/bootstrap.min.js') }}">
    </script>
    <script src="{{ asset('js/bootsnav.js') }}">
    </script>
    <script src="{{ asset('js/jquery.parallax-1.1.3.js') }}">
    </script>
    <script src="{{ asset('js/jquery.appear.js') }}">
    </script>
    <script src="{{ asset('js/owl.carousel.min.js') }}">
    </script>
    <script src="{{ asset('js/jquery.cubeportfolio.min.js') }}">
    </script>
    <script src="{{ asset('js/jquery.fancybox.js') }}">
    </script>
    <script src="{{ asset('js/jquery.themepunch.tools.min.js') }}">
    </script>
    <script src="{{ asset('js/jquery.themepunch.revolution.min.js') }}">
    </script>
    <script src="{{ asset('js/revolution.extension.layeranimation.min.js') }}">
    </script>
    <script src="{{ asset('js/revolution.extension.navigation.min.js') }}">
    </script>
    <script src="{{ asset('js/revolution.extension.parallax.min.js') }}">
    </script>
    <script src="{{ asset('js/revolution.extension.slideanims.min.js') }}">
    </script>
    <script src="{{ asset('js/revolution.extension.video.min.js') }}">
    </script>
    <script src="{{ asset('js/kinetic.js') }}">
    </script>
    <script src="{{ asset('js/jquery.final-countdown.js') }}">
    </script>
    <script src="{{ asset('js/functions.js') }}">
    </script>


</body>
</html>

 